﻿using System.Text;
using System.Net;
var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient("ApiClient", client => { client.BaseAddress = new Uri("http://localhost:5110"); });
var app = builder.Build();

// Метод основного вида сайта
string GetLayout(string title, string content, bool isLoggedIn = false) => $$"""
<html>
<head>
    <title>{{title}}</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Verdana, sans-serif; margin: 0; background-color: #f4f4f9; color: #333; }
       header { 
    background: #2b2b2b; 
    padding: 15px 30px; 
    color: white; 
    /* Расталкиваем логотип влево, а навигацию вправо */
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
}

/* Контейнер для ссылок справа */
.auth-nav {
    display: flex;
    gap: 20px; /* Расстояние между Входом и Регистрацией */
}

header a { 
    color: #fff; 
    text-decoration: none; 
    font-size: 16px; 
    font-weight: 500; 
    transition: color 0.3s;
}

header a:hover {
    color: #007185; /* Подсветка при наведении */
}

.logo {
    font-size: 18px;
    font-weight: bold;
}
        .container { padding: 40px; max-width: 800px; margin: auto; }
        .form-box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .form-box input { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .form-box select { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; }
        .form-box button { width: 100%; padding: 12px; background: #007185; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 16px; }
        .form-box button:hover { background: #005a6a; }
        .result-box { background: #e7f4e4; border: 1px solid #d4e8ce; padding: 15px; border-radius: 4px; margin-bottom: 20px; text-align: center; font-size: 1.2em; }
        .result-box a { color: #007185; font-weight: bold; }
    </style>
</head>
<body>
    <header>
        <a href="/" class="logo">✂️ Link-Length-Minimizer</a>
        <nav class="auth-nav">
            {{(isLoggedIn ?"<a href=\"/logout\">Выход</a>" : "<a href=\"/signin\">Вход</a> <a href=\"/signup\">Регистрация</a>")}}
        </nav>
    </header>
    <div class="container">
        {{content}}
    </div>
</body>
</html>
""";

app.MapGet("/", async (IHttpClientFactory factory, HttpContext context) =>
{
    bool isLoggedIn = context.Request.Cookies.ContainsKey("userId");
    var contentBuilder = new StringBuilder();
    if (isLoggedIn)
    {
        var successCode = context.Request.Query["successCode"].ToString();
        var errorUrl = context.Request.Query["error"].ToString();
        if (!string.IsNullOrEmpty(successCode))
        {
            contentBuilder.Append($$$"""<div class="result-box">Ссылка успешно сокращена: <a href="/{{{successCode}}}" target="_blank">http://localhost:5000/{{{successCode}}}</a></div>""");
        }
        if (!string.IsNullOrEmpty(errorUrl))
        {
            contentBuilder.Append($$$"""<div class="result-box" style="background:#ffe6e6; border-color:#f5c6c6; color:red;">Ошибка: {{{errorUrl}}}</div>""");
        }
        contentBuilder.Append("""
            <div class="form-box">
                <h2>Сократить ссылку</h2>
                <form method="post" action="/shorten">
                    <label>Вставьте длинную ссылку:</label>
                    <input type="url" name="originalUrl" placeholder="https://example.com" required />
                    <button type="submit">Сократить</button>
                </form>
            </div>
         """);
        var client = factory.CreateClient("ApiClient");
        var request = new HttpRequestMessage(HttpMethod.Get, "/api");
        if (context.Request.Headers.TryGetValue("Cookie", out var cookies)) request.Headers.Add("Cookie", cookies.ToString());
        var response = await client.SendAsync(request);
        if (response.IsSuccessStatusCode)
        {
            var links = await response.Content.ReadFromJsonAsync<List<LinkViewModel>>() ?? new();
            contentBuilder.Append("<h3>Ваша история ссылок</h3><table>");
            contentBuilder.Append("<tr><th>Код</th><th>Оригинал</th><th>Действие</th></tr>");
            foreach (var link in links)
            {
                contentBuilder.Append($$"""
                 <tr>
                    <td><strong><a href="/{{link.ShortCode}}" target="_blank">{{link.ShortCode}}</a></strong></td>
                    <td>{{link.OriginalUrl}}</td>
                    <td><a href="/delete/{{link.Id}}" onclick="return confirm('Удалить?')">X</a></td>
                 </tr>
                 """);
            }
            contentBuilder.Append("</table>");
        }
        else if (response.StatusCode == HttpStatusCode.Unauthorized) return Results.Redirect("/signin");
    }
    else contentBuilder.Append("<p>Пожалуйста, войдите в систему.</p>");
    return Results.Content(GetLayout("Главная", contentBuilder.ToString(), isLoggedIn), "text/html; charset=utf-8");
});
//Главная страница
//Генерация ссылки
app.MapPost("/shorten", async (HttpContext context, IHttpClientFactory factory) =>
{
    var form = await context.Request.ReadFormAsync();
    string originalUrl = form["originalUrl"].ToString();
    var client = factory.CreateClient("ApiClient");
    var request = new HttpRequestMessage(HttpMethod.Post, "/api/shorten");

    if (!Uri.TryCreate(originalUrl, UriKind.Absolute, out var uriResult) || (uriResult.Scheme != Uri.UriSchemeHttp && uriResult.Scheme != Uri.UriSchemeHttps))
        return Results.Redirect("/?error=" + Uri.EscapeDataString("Некорректный формат URL"));

    request.Content = JsonContent.Create(new { originalUrl });
    if (context.Request.Headers.TryGetValue("Cookie", out var cookies)) request.Headers.Add("Cookie", cookies.ToString());

    var response = await client.SendAsync(request);

    if (response.IsSuccessStatusCode)
    {
        var link = await response.Content.ReadFromJsonAsync<LinkViewModel>();
        return Results.Redirect($"/?successCode={link?.ShortCode}");
    }
    var errorContent = await response.Content.ReadAsStringAsync();
    string details = $"Код {response.StatusCode}: {errorContent}";

    return Results.Redirect("/?error=" + Uri.EscapeDataString(details));
});
// Обработчик перенаправления
app.MapGet("/{code}", async (string code, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var response = await client.GetAsync($"/api/{code}");

    if (response.IsSuccessStatusCode)
    {
        string originalUrl = await response.Content.ReadAsStringAsync();

        // Срезаем кавычки по краям, чтобы ссылка стала валидной
        string cleanUrl = originalUrl.Trim('"');

        return Results.Redirect(cleanUrl);
    }

    return Results.Redirect("/?error=NotFound");
});
// Отображение страницы входа
app.MapGet("/signin", (HttpContext context) =>
{
    var contentBuilder = new StringBuilder();
    var errorMsg = context.Request.Query["error"];
    if (errorMsg == "Wrong password")
    {
        contentBuilder.Append("""<div class="result-box" style="background:#ffe6e6; border-color:#f5c6c6; color:red;">Ошибка: Неправильный логин или пароль.</div>""");
    }

    contentBuilder.Append("""
        <div class="form-box">
            <h2>Вход</h2>
            <form method="post" action="/signin"> <label>Введите имя пользователя:</label>
                <input type="text" name="username" placeholder="Username" required /><br>
                <label>Введите пароль:</label>
                <input type="password" name="password" placeholder="Password" required />


                <button type="submit">Войти</button>
            </form>
        </div>
     """);
    return Results.Content(GetLayout("Логин", contentBuilder.ToString(), false), "text/html; charset=utf-8");
});

// Обработка данных входа
app.MapPost("/signin", async (HttpContext context, IHttpClientFactory factory) =>
{
    var form = await context.Request.ReadFormAsync();
    var username = form["username"].ToString();
    var password = form["password"].ToString();

    var client = factory.CreateClient("ApiClient");
    var response = await client.PostAsJsonAsync("/api/auth/signin", new { username, password });
    if (response.IsSuccessStatusCode)
    {
        var userId = await response.Content.ReadAsStringAsync();

        context.Response.Cookies.Append("userId", userId.Trim('"'));

        return Results.Redirect("/");
    }
    return Results.Redirect("/signin?error=Wrong password");
});
//регистрация мапгет
app.MapGet("/signup", (HttpContext context) =>
{
    var contentBuilder = new StringBuilder();
    var errorMsg = context.Request.Query["error"];
    if (errorMsg == "User exists")
    {
        contentBuilder.Append("""<div class="result-box" style="background:#ffe6e6; border-color:#f5c6c6; color:red;">Ошибка: Пользователь уже существует.</div>""");
    }

    contentBuilder.Append("""
        <div class="form-box">
            <h2>Регистрация</h2>
            <form method="post" action="/signup">
                <label>Придумайте имя пользователя:</label>
                <input type="text" name="username" placeholder="Username" required /><br>
                <label>Придумайте пароль:</label>
                <input type="password" name="password" placeholder="Password" required />

                <button type="submit">Зарегистрироваться</button>
            </form>
            <p style="text-align:center;">Уже есть аккаунт? <a href="/signin">Войти</a></p>
        </div>
     """);
    return Results.Content(GetLayout("Регистрация", contentBuilder.ToString(), false), "text/html; charset=utf-8");
});
//Регистрация МапПост
app.MapPost("/signup", async (HttpContext context, IHttpClientFactory factory) =>
{
    var form = await context.Request.ReadFormAsync();
    var username = form["username"].ToString();
    var password = form["password"].ToString();

    var client = factory.CreateClient("ApiClient");
    var response = await client.PostAsJsonAsync("/api/auth/signup", new { username, password });
    if (response.IsSuccessStatusCode) return Results.Redirect("/signin");
    return Results.Redirect("/signup?error=User exists");
});
//выход с аккаунта
app.MapGet("/logout", (HttpContext context) =>
{
    context.Response.Cookies.Delete("userId");
    return Results.Redirect("/");
});
//Удаление
app.MapGet("/delete/{id:int}", async (int id, IHttpClientFactory factory, HttpContext context) =>
{
    var client = factory.CreateClient("ApiClient");
    var request = new HttpRequestMessage(HttpMethod.Delete, $"/api/delete/{id}");
    if (context.Request.Headers.TryGetValue("Cookie", out var cookies)) request.Headers.Add("Cookie", cookies.ToString());
    var response = await client.SendAsync(request);
    if (response.StatusCode == HttpStatusCode.Unauthorized) return Results.Redirect("/signin");
    if (response.StatusCode == HttpStatusCode.NotFound) return Results.NotFound("Ссылка не найдена.");
    return Results.Redirect("/");
});
// Запускаем приложение
await app.RunAsync();
public class LinkViewModel
{
    public int Id { get; set; }
    public string ShortCode { get; set; } = string.Empty;
    public string OriginalUrl { get; set; } = string.Empty;
}