using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;
using System.Text;

// Создаём builder приложения.
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite("Data Source=links.db"));
// Фоновый процесс
builder.Services.AddHostedService<CleanupBackgroundService>();

// Собираем приложение.
var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    // Автоматически создаём базу данных и таблицы, если их нет.
    await db.Database.EnsureCreatedAsync();
}

app.MapPost("/api/auth/signup", async (AuthData req, AppDbContext db) =>
{
    if (await db.Users.AnyAsync(u => u.Username == req.Username)) return Results.Conflict();
    db.Users.Add(new User { Username = req.Username, PasswordHash = req.Password });
    await db.SaveChangesAsync();
    return Results.Ok();
});

app.MapPost("/api/auth/signin", async (AuthData req, AppDbContext db) =>
{
    var user = await db.Users.FirstOrDefaultAsync(u => u.Username == req.Username && u.PasswordHash == req.Password);
    if (user == null) return Results.Unauthorized();
    return Results.Ok(user.Id.ToString());
});


app.MapGet("/api", async (HttpContext context, AppDbContext db) => {
    int? userId = GetUserId(context);
    if (!userId.HasValue) return Results.Json(new { error = "Unauthorized" }, statusCode: 401);
    var links = await db.Links.Where(l => l.UserId == userId.Value).OrderByDescending(l => l.CreatedAt).Select(l => new {
        l.Id,
        l.ShortCode,
        l.OriginalUrl,
        l.ExpiresAt
    }).ToListAsync();
    return Results.Json(links);
});
//HTTP метод mapDelete :/
app.MapDelete("/api/delete/{id}", async (int id, HttpContext context, AppDbContext db) => {
    int? userId = GetUserId(context);
    if (!userId.HasValue) return Results.Json(new { error = "Unauthorized" }, statusCode: 401);

    var link = await db.Links.FirstOrDefaultAsync(l => l.Id == id && l.UserId == userId.Value);
    if (link != null)
    {
        db.Links.Remove(link);
        await db.SaveChangesAsync();
    }
    return Results.Ok();
});
app.MapPost("/api/shorten", async (ShortenRequest req, HttpContext context, AppDbContext db) =>
{
    int? userId = GetUserId(context);
    if (!userId.HasValue) return Results.Json(new { error = "Unauthorized" }, statusCode: 401);
    if (string.IsNullOrWhiteSpace(req.OriginalUrl)) return Results.BadRequest("URL cannot be empty");
    string code = GenerateShortCode(6);
    var newLink = new ShortLink
    {
        ShortCode = code,
        OriginalUrl = req.OriginalUrl,
        UserId = userId.Value,
        CreatedAt = DateTime.UtcNow,
        ExpiresAt = DateTime.UtcNow.AddMinutes(5)
    };
    db.Links.Add(newLink);
    await db.SaveChangesAsync();
    return Results.Ok(newLink);
});
app.MapGet("/api/{code}", async (string code, AppDbContext db) => {
    var link = await db.Links.FirstOrDefaultAsync(l => l.ShortCode == code);
    if (link == null || link.ExpiresAt < DateTime.UtcNow) return Results.NotFound();
    return Results.Ok(link.OriginalUrl);
});
app.Run();
int? GetUserId(HttpContext context)
{
    var id = context.Request.Cookies["userId"];
    if (string.IsNullOrEmpty(id)) return null;
    return int.Parse(id);
}
static string GenerateShortCode(int length)
{
    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var stringChars = new char[length];
    var random = new Random();

    for (int i = 0; i < length; i++)
    {
        stringChars[i] = chars[random.Next(chars.Length)];
    }

    return new string(stringChars);
}
public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public List<ShortLink> Links { get; set; } = new();
}
// Модель для хранения коротких ссылок
public class ShortLink
{
    public int Id { get; set; }
    public string ShortCode { get; set; } = string.Empty;
    public string OriginalUrl { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime ExpiresAt { get; set; }
    public int UserId { get; set; }
    public User User { get; set; } = null!;
}

// База данных
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<ShortLink> Links => Set<ShortLink>();

    public DbSet<User> Users => Set<User>();


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ShortLink>()
            .HasIndex(x => x.ShortCode)
            .IsUnique();
    }
}

// Фоновый процесс для очистки БД от истёкших ссылко
public class CleanupBackgroundService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;
    private readonly ILogger<CleanupBackgroundService> _logger;

    public CleanupBackgroundService(IServiceProvider serviceProvider, ILogger<CleanupBackgroundService> logger)
    {
        _serviceProvider = serviceProvider;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Сервис автоматиечской очистки ссылок запущен.");

        // Крутим цикл, пока приложение работает
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                // Запускаем очистку в отдельном scope , тк контекст БД имеет время жизни Scoped
                using (var scope = _serviceProvider.CreateScope())
                {
                    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                    var now = DateTime.UtcNow;

                    // Находим все ссылки, время жизни которых истекло
                    var expiredLinks = await db.Links
                        .Where(x => x.ExpiresAt < now)
                        .ToListAsync(stoppingToken);

                    if (expiredLinks.Any())
                    {
                        db.Links.RemoveRange(expiredLinks);
                        await db.SaveChangesAsync(stoppingToken);
                        _logger.LogInformation($"Удалено устаревших ссылок: {expiredLinks.Count}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при выполнении автоматической очистки базы данных.");
            }

            // Ждём 1 минуту до проверки
            await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
        }
    }
}
public class ShortenRequest
{
    public string OriginalUrl { get; set; } = string.Empty;
}

// Вспомогательный класс для приёма данных регистрации/входа
public class AuthData
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}